import tkinter as tk
from tkinter import filedialog, messagebox
import pandas as pd
import threading
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, f1_score
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
import xgboost as xgb
import lightgbm as lgb
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from PIL import Image, ImageTk
import warnings
warnings.filterwarnings("ignore")

# =================== CONSTANTS ===================
TITLE_FONT = ("Helvetica", 18, "bold")
BTN_FONT = ("Helvetica", 10, "bold")
TEXT_FONT = ("Consolas", 10)
BG_COLOR = "#f7fbff"
BTN_COLOR = "#1E90FF"
BTN_HOVER = "#1c7bd9"
CANCEL_MAP = {0: "Not Canceled", 1: "Canceled"}

# =================== LOGIN PAGE ===================
class LoginPage:
    def __init__(self, root):
        self.root = root
        root.title("Login - Hotel Booking Cancellation Forecast")
        root.geometry("420x320")
        root.minsize(360, 280)

        self.canvas = tk.Canvas(root)
        self.canvas.pack(fill="both", expand=True)
        self.canvas.bind("<Configure>", self.redraw_gradient)

        # Card frame
        self.card = tk.Frame(root, bg="white", bd=2, relief="groove")
        self.card_id = self.canvas.create_window(0, 0, window=self.card, width=340, height=220)

        # Labels and entries
        tk.Label(self.card, text="Hotel Booking Forecast",
                 font=("Arial", 14, "bold"), bg="white").pack(pady=(12, 6))
        tk.Label(self.card, text="Username", bg="white").pack(anchor="w", padx=20)
        self.username = tk.Entry(self.card, width=30)
        self.username.pack(padx=20, pady=4)
        tk.Label(self.card, text="Password", bg="white").pack(anchor="w", padx=20)
        self.password = tk.Entry(self.card, width=30, show="*")
        self.password.pack(padx=20, pady=4)
        self.show_var = tk.IntVar()
        tk.Checkbutton(self.card, text="Show password",
                       variable=self.show_var, bg="white",
                       command=self.toggle_password).pack(anchor="w", padx=20)

        # Buttons
        btn_frame = tk.Frame(self.card, bg="white")
        btn_frame.pack(pady=10)
        tk.Button(btn_frame, text="Login", width=10,
                  bg="#28a745", fg="white",
                  command=self.login).grid(row=0, column=0, padx=8)
        tk.Button(btn_frame, text="Cancel", width=10,
                  bg="#dc3545", fg="white",
                  command=root.quit).grid(row=0, column=1, padx=8)

    def redraw_gradient(self, event=None):
        self.canvas.delete("grad")
        w = self.canvas.winfo_width()
        h = self.canvas.winfo_height()
        c1, c2 = "#89CFF0", "#1E90FF"                                   
        for i in range(h):
            r = int(int(c1[1:3], 16) + (int(c2[1:3], 16) - int(c1[1:3], 16)) * i / h)
            g = int(int(c1[3:5], 16) + (int(c2[3:5], 16) - int(c1[3:5], 16)) * i / h)
            b = int(int(c1[5:7], 16) + (int(c2[5:7], 16) - int(c1[5:7], 16)) * i / h)
            self.canvas.create_line(0, i, w, i, fill=f"#{r:02x}{g:02x}{b:02x}", tags="grad")
        self.canvas.coords(self.card_id, w/2, h/2)

    def toggle_password(self):
        self.password.config(show="" if self.show_var.get() else "*")

    def login(self):
        if self.username.get() == "admin" and self.password.get() == "admin":
            self.root.destroy()
            root = tk.Tk()
            MainApp(root)
            root.mainloop()
        else:
            messagebox.showerror("Login Failed", "Invalid username or password")


# =================== MAIN APPLICATION ===================
class MainApp:
    def __init__(self, root):
        self.root = root
        root.title("Hotel Booking Cancellation Prediction")
        root.geometry("1200x700")
        root.minsize(900, 600)
        self.bg_label = tk.Label(root)
        self.bg_label.place(x=0, y=0, relwidth=1, relheight=1)
        root.bind("<Configure>", self.redraw_bg)

        # Variables
        self.columns_to_drop = [
            "name", "Name", "email", "Email",
            "phone no", "phone-no", "phone-number", "phone_number", "phone_no", "phone",
            "credit card", "credit_card", "credit-card",
            "reservation_status_date", "reservation status date",
            "adr"
        ]
        self.df = None
        self.train_cols = None
        self.target_col = "is_canceled"
        self.models = {}
        self.encoders = {}
        self.last_split = None
        self.last_trained_model_name = None

        # Title
        self.title_label = tk.Label(root,
                                    text="Hotel Booking Cancellation Forecast System",
                                    font=TITLE_FONT, bg=BG_COLOR, fg="#0b4f8a")
        self.title_label.place(relx=0.5, y=10, anchor="n")

        # Main frame
        self.main_frame = tk.Frame(root, bg=BG_COLOR)
        self.main_frame.place(x=20, y=50, relwidth=0.96, relheight=0.9)

        # Left frame (Text area + Buttons)
        self.left_frame = tk.Frame(self.main_frame, bg=BG_COLOR, bd=2, relief="ridge")
        self.left_frame.place(relx=0, rely=0, relwidth=0.6, relheight=1)

        # Text area
        self.text_area = tk.Text(self.left_frame, font=TEXT_FONT, wrap="none")
        self.text_area.place(relx=0, rely=0, relwidth=0.7, relheight=1)
        y_scroll = tk.Scrollbar(self.left_frame, command=self.text_area.yview)
        y_scroll.place(relx=0.7, rely=0, relwidth=0.03, relheight=1)
        x_scroll = tk.Scrollbar(self.left_frame, orient="horizontal", command=self.text_area.xview)
        x_scroll.place(relx=0, rely=0.95, relwidth=0.7, relheight=0.05)
        self.text_area.configure(yscrollcommand=y_scroll.set, xscrollcommand=x_scroll.set)

        # Button panel
        self.btn_frame = tk.Frame(self.left_frame, bg=BG_COLOR)
        self.btn_frame.place(relx=0.73, rely=0, relwidth=0.27, relheight=1)

        def make_button(text, cmd):
            btn = tk.Button(self.btn_frame, text=text, font=BTN_FONT,
                            bg=BTN_COLOR, fg="white",
                            activebackground=BTN_HOVER,
                            width=19, height=2,
                            command=cmd)
            btn.pack(pady=8)
            btn.bind("<Enter>", lambda e: btn.configure(bg=BTN_HOVER))
            btn.bind("<Leave>", lambda e: btn.configure(bg=BTN_COLOR))
            return btn

        # Buttons
        make_button("Upload Dataset", self.upload_file)
        make_button("Preprocess Dataset", self.preprocess_data)
        make_button("Train Logistic Regression", lambda: self.train_single("Logistic Regression"))
        make_button("Train Decision Tree", lambda: self.train_single("Decision Tree"))
        make_button("Train Random Forest", lambda: self.train_single("Random Forest"))
        make_button("Train XGBoost", lambda: self.train_single("XGBoost"))
        make_button("Train LightGBM", lambda: self.train_single("LightGBM"))
        make_button("Show Comparison Graphs", self.show_comparison_graphs)
        make_button("Predict (Upload CSV)", self.predict_from_file)
        make_button("Logout", self.logout)

        # Right frame (Image)
        self.right_frame = tk.Frame(self.main_frame, bg=BG_COLOR, bd=2, relief="ridge")
        self.right_frame.place(relx=0.6, rely=0, relwidth=0.4, relheight=1)

        try:
            self.bg_original = Image.open(r"D:\hotels\img.jpg")  # update path
        except Exception as e:
            print("Background image failed:", e)
            self.bg_original = None

        self.bg_label_right = tk.Label(self.right_frame)
        self.bg_label_right.place(relx=0, rely=0, relwidth=1, relheight=1)
        self.redraw_bg()

    # ===== Dynamic Gradient or Image =====
    def redraw_bg(self, event=None):
        w = self.right_frame.winfo_width()
        h = self.right_frame.winfo_height()
        if self.bg_original and w > 0 and h > 0:
            img = self.bg_original.resize((w, h), Image.Resampling.LANCZOS)
            self.bg_photo = ImageTk.PhotoImage(img)
            self.bg_label_right.config(image=self.bg_photo)
        else:
            gradient = Image.new("RGB", (w, h), "#f7fbff")
            self.bg_photo = ImageTk.PhotoImage(gradient)
            self.bg_label_right.config(image=self.bg_photo)

    # ================== LOGIC & PREDICTION ==================
    def upload_file(self):
        self.text_area.delete("1.0", tk.END)
        fp = filedialog.askopenfilename(filetypes=[("CSV Files", "*.csv")])
        if not fp:
            self.text_area.insert(tk.END, "No file selected.\n")
            return
        try:
            df = pd.read_csv(fp)
            df.drop(columns=self.columns_to_drop, inplace=True, errors='ignore')
            self.encoders = {}
            df_display = df.copy()
            for col in df_display.columns:
                if df_display[col].dtype == 'object':
                    df_display[col] = pd.Categorical(df_display[col]).codes
                    mapping = {cat: code for code, cat in enumerate(pd.Categorical(df[col]).categories)}
                    self.encoders[col] = mapping
            self.df = df
            self.text_area.insert(tk.END, f"Loaded dataset: {fp}\nShape: {self.df.shape}\n")
            self.text_area.insert(tk.END, "------ Random sample (10 rows) ------\n")
            self.text_area.insert(tk.END, df_display.sample(min(10, len(df_display))).to_string(index=False))
            self.text_area.insert(tk.END, "\n\nClick 'Preprocess Dataset' to continue.\n")
            # ===== Prepare numeric columns =====
            numeric_cols = df.select_dtypes(include=['int64', 'float64'])
            # ===== Correlation heatmap popup =====
            if len(numeric_cols.columns) > 1:
                popup = tk.Toplevel(self.root)
                popup.title("Correlation Heatmap")
                popup.geometry("800x600")
                fig, ax = plt.subplots(figsize=(8, 6))
                sns.heatmap(numeric_cols.corr(), annot=True, fmt=".2f", cmap="coolwarm", ax=ax)
                ax.set_title("Correlation Heatmap")
                canvas = FigureCanvasTkAgg(fig, master=popup)
                canvas.draw()
                canvas.get_tk_widget().pack(fill="both", expand=True)

        except Exception as e:
            messagebox.showerror("Error", f"Failed to load dataset: {e}")

    def preprocess_data(self):
        if self.df is None:
            messagebox.showwarning("No File", "Please upload a dataset first.")
            return
        try:
            df = self.df.copy().drop_duplicates()
            df.drop(columns=self.columns_to_drop, inplace=True, errors='ignore')
            self.encoders = {}
            for col in df.columns:
                if df[col].dtype.kind in "biufc":
                    df[col].fillna(df[col].median(), inplace=True)
                else:
                    df[col].fillna(df[col].mode()[0], inplace=True)
                    df[col] = df[col].astype("category")
                    mapping = {cat: code for code, cat in enumerate(df[col].cat.categories)}
                    self.encoders[col] = mapping
                    df[col] = df[col].cat.codes
            if self.target_col not in df.columns:
                messagebox.showerror("Error", f"Target column '{self.target_col}' not found.")
                return
            X = df.drop(columns=[self.target_col])
            y = df[self.target_col]
            self.train_cols = list(X.columns)
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.2, random_state=42, stratify=y
            )
            self.last_split = (X_train.reset_index(drop=True), X_test.reset_index(drop=True),
                               y_train.reset_index(drop=True), y_test.reset_index(drop=True))
            self.text_area.insert(tk.END, f"Total Records : {len(df)}\n")
            self.text_area.insert(tk.END, f"Training Rows : {len(X_train)}\n")
            self.text_area.insert(tk.END, f"Testing Rows  : {len(X_test)}\n")

            # Bar graph popup
            popup = tk.Toplevel(self.root)
            popup.title("Class Distribution After Preprocessing")
            popup.geometry("600x400")
            fig = plt.Figure(figsize=(6, 4))
            ax = fig.add_subplot(111)
            y_display = y.map({0: "Not Canceled", 1: "Canceled"})
            y_display.value_counts().plot(kind='bar', ax=ax, color=["green", "red"])
            ax.set_title("Canceled vs Not Canceled")
            ax.set_xlabel("Booking Status")
            ax.set_ylabel("Count")
            ax.set_xticklabels(["Not Canceled", "Canceled"], rotation=0)
            canvas = FigureCanvasTkAgg(fig, master=popup)
            canvas.draw()
            canvas.get_tk_widget().pack(fill="both", expand=True)

        except Exception as e:
            messagebox.showerror("Error", f"Preprocessing failed: {e}")

    def _get_model_by_name(self, name):
        if name == "Logistic Regression":
            return LogisticRegression(max_iter=2000)
        if name == "Decision Tree":
            return DecisionTreeClassifier(max_depth=4, random_state=72)
        if name == "Random Forest":
            return RandomForestClassifier(n_estimators=200, max_depth=6, random_state=42)
        if name == "XGBoost":
            return xgb.XGBClassifier(objective='binary:logistic', eval_metric='logloss',
                                     max_depth=5, learning_rate=0.1, use_label_encoder=False, random_state=42)
        if name == "LightGBM":
            return lgb.LGBMClassifier(objective='binary', num_leaves=50, max_depth=7, random_state=42)
        raise ValueError("Unknown model name")

    def train_single(self, model_name):
        if not self.last_split:
            messagebox.showwarning("Info", "Preprocess dataset first.")
            return
        def _train():
            try:
                X_train, X_test, y_train, y_test = self.last_split
                scaler = StandardScaler()
                X_train_s = scaler.fit_transform(X_train)
                X_test_s = scaler.transform(X_test)
                model = self._get_model_by_name(model_name)
                self.text_area.insert(tk.END, f"\n🔹 Training {model_name} ...\n")
                model.fit(X_train_s, y_train)
                y_pred = model.predict(X_test_s)
                acc = accuracy_score(y_test, y_pred)
                f1 = f1_score(y_test, y_pred)
                self.models[model_name] = (model, scaler, acc, f1)
                best_model = max(self.models.items(), key=lambda x: x[1][2])
                self.last_trained_model_name = best_model[0]
                self.text_area.insert(tk.END, f"✅ {model_name} Accuracy: {acc:.4f}  F1: {f1:.4f}\n")
                if len(self.models) == 5:
                    best_name = best_model[0]
                    best_acc = best_model[1][2]
                    best_f1 = best_model[1][3]
                    self.text_area.insert(tk.END, f"\n🎯 FINAL BEST MODEL: {best_name}\nAccuracy: {best_acc:.4f}\nF1 Score: {best_f1:.4f}\n")
            except Exception as e:
                self.text_area.insert(tk.END, f"❌ Error training {model_name}: {e}\n")
        threading.Thread(target=_train, daemon=True).start()

    def show_comparison_graphs(self):
        if not self.models:
            messagebox.showwarning("Info", "Train at least one model first.")
            return
        names = list(self.models.keys())
        acc_vals = [v[2] for v in self.models.values()]
        popup = tk.Toplevel(self.root)
        popup.title("Model Comparison")
        popup.geometry("1000x500")
        fig, axes = plt.subplots(1, 2, figsize=(14, 5))
        sns.barplot(x=acc_vals, y=names, ax=axes[0], palette="viridis")
        axes[0].set_title("Accuracy Comparison")
        axes[1].pie(acc_vals, labels=names, autopct="%1.1f%%", startangle=140,
                    colors=sns.color_palette("pastel", len(names)))
        axes[1].set_title("Accuracy Distribution")
        canvas = FigureCanvasTkAgg(fig, master=popup)
        canvas.draw()
        canvas.get_tk_widget().pack(fill="both", expand=True)

    def predict_from_file(self):
        if not self.last_trained_model_name:
            messagebox.showwarning("Info", "Train a model first.")
            return
        fp = filedialog.askopenfilename(filetypes=[("CSV Files", "*.csv")])
        if not fp:
            return
        try:
            dfp = pd.read_csv(fp)
            dfp.drop(columns=self.columns_to_drop, inplace=True, errors='ignore')
            dfp.replace([float("inf"), float("-inf")], pd.NA, inplace=True)

            for col in dfp.columns:
                if dfp[col].dtype.kind in "biufc":
                    dfp[col].fillna(0, inplace=True)
                else:
                    dfp[col].fillna(-1, inplace=True)
            for col in dfp.columns:
                if col in self.encoders:
                    dfp[col] = dfp[col].map(self.encoders[col])
                    dfp[col].fillna(dfp[col].mode()[0], inplace=True)
                    dfp[col] = dfp[col].astype(int)

            for c in self.train_cols:
                if c not in dfp.columns:
                    dfp[c] = 0
            dfp = dfp[self.train_cols]
            model, scaler, _, _ = self.models[self.last_trained_model_name]
            preds = model.predict(scaler.transform(dfp))
            preds_str = [CANCEL_MAP[p] for p in preds]
            dfp["Prediction"] = preds_str
            popup = tk.Toplevel(self.root)
            popup.title("Prediction Results")
            popup.geometry("900x600")
            frame = tk.Frame(popup)
            frame.pack(fill="both", expand=True)
            text = tk.Text(frame, wrap="none", font=("Consolas", 10))
            text.pack(side="left", fill="both", expand=True)
            y_scroll = tk.Scrollbar(frame, orient="vertical", command=text.yview)
            y_scroll.pack(side="right", fill="y")
            x_scroll = tk.Scrollbar(popup, orient="horizontal", command=text.xview)
            x_scroll.pack(side="bottom", fill="x")
            text.configure(yscrollcommand=y_scroll.set, xscrollcommand=x_scroll.set)
            text.insert(tk.END, dfp.to_string(index=False))
        except Exception as e:
            messagebox.showerror("Error", f"Prediction failed: {e}")

    def logout(self):
        self.root.destroy()
        root = tk.Tk()
        LoginPage(root)
        root.mainloop()


# =================== RUN APPLICATION ===================
if __name__ == "__main__":
    root = tk.Tk()
    LoginPage(root)
    root.mainloop()
